import kaboom from "kaboom";

kaboom({
  background: [134, 135, 247],
  width: 900,
  height: 400,
  scale: 2,
});

loadRoot("sprites/");
loadAseprite("mario", "Mario.png", "Mario.json");
loadAseprite("enemies", "enemies.png", "enemies.json");
loadSprite("ground", "ground.png");
loadSprite("questionBox", "questionBox.png");
loadSprite("emptyBox", "emptyBox.png");
loadSprite("brick", "brick.png");
loadSprite("coin", "coin.png");
loadSprite("bigMushy", "bigMushy.png");
loadSprite("pipeTop", "pipeTop.png");
loadSprite("pipeBottom", "pipeBottom.png");
loadSprite("shrubbery", "shrubbery.png");
loadSprite("hill", "hill.png");
loadSprite("cloud", "cloud.png");
loadSprite("castle", "castle.png");
loadSprite("rb", "rb.png");
loadSprite("moss", "moss.png");
loadSprite("lava", "lava.png");
loadSprite("Volcano", "Volcano.png");
loadSprite("Ocean", "Ocean.png");
loadSprite("pink", "pink.png");
loadSprite("smoke", "smoke.png");
loadSprite("smokeCloud", "smokeCloud.png");
loadSprite("clownFish", "clownFish.png");
loadSprite("blueTang", "blueTang.png");
loadSprite("sea", "sea.png");
loadSprite("gold", "gold.png");

const LEVELS = [
  [
    "                                                                     d  \
                            d                   ",
    "                                                                        \
                                                ",
    "                                       d                                \
    d                                          ",
    "                                                                        \
                                                ",
    "             d                                              d           \
                                          d     ",
    "                                                                        \
                                                ",
    "                                                                        \
                                                ",
    "                                                                        \
                                                ",
    "                                                                        \
                                                ",
    "                                                                        \
                                                ",
    "     -?-b-                                                              \
                                                ",
    "                                              ?        ?                \
                                                ",
    "                                                                        \
                                                ",
    "                                   _                  ?            E     \
                                                ",
    "                              _    |                              -b?-    \
                                                ",
    "                           _  |    |          _                            \
        _                                       ",
    "       E                   |  |    |  E  E    |                            \
        |   EE                        H         ",
    "================     ======================================================\
=================================================",
    "================     ======================================================\
=================================================",
  ],
  [
    "                                                       d                   \
                                                ",
    "     d                                                                     \
            d                                   ",
    "                                          d                    d           \
                                d               ",
    "                                                                          d\
                        d                       ",
    "      d                                                                    \
                                                ",
    "                                                    d                      \
                                      d        ",
    "                     d                                          d          \
                d                               ",
    "                                                                           \
                                                ",
    "                                                                           \
                                                ",
    "                                                                           \
                                                ",
    "                                                                           \
                                                ",
    "                                                                        ?b?\
                  ----?                        ",
    "                                            E                              \
                                                ",
    "         ?              --                 --?-                            \
                            -?-                 ",
    "                              --b-                      -??-               \
                                                ",
    "                                                                           \
         _ ---                                   ",
    "          E                                                          EE    \
         |                    E        H         ",
    "================     ======================================================\
=================================================",
    "================     ======================================================\
=================================================",
  ],
  [
    "                            d                               d              \
                      d                         ",
    "                                                                           \
                                                ",
    "                                               d                           \
      d                                         ",
    "                                                                           \
                                                ",
    "                                                                     d     \
              d                        d       ",
    "                                                                           \
                            d                   ",
    "                                                         d                 \
                                                ",
    "                                                                           \
                                                ",
    "            m??m                                                           \
                                                ",
    "                                                                           \
                                                ",
    "                                              mm                           \
                                                ",
    "                                   m??                                     \
                                                ",
    "                                                                           \
                    m??m                        ",
    "       mmb                                mm                               \
                                                ",
    "                                                         mmBm?             \
                                                ",
    "                       m                             _ _                   \
                                                ",
    "    E                 mmm                  E         | |         E E       \
            m                           H       ",
    "mmmmmmmmmmmmmmmmmmmmmmmmm     mmmmmmmmmmmmmmm     mmmmmmmmmmmmmmmmmmmmmmmmm\
mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm",
    "mmmmmmmmmmmmmmmmmmmmmmmmm     mmmmmmmmmmmmmmm     mmmmmmmmmmmmmmmmmmmmmmmmm\
mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm",
  ],
  [
    "                                                                           \
                                                ",
    "                                                                           \
                                                ",
    "                                                                           \
                                                ",
    "                                                                           \
                                                ",
    "                                                                           \
                                                ",
    "                                                                           \
                                                ",
    "                                                                           \
                                                ",
    "                                                                           \
                                                ",
    "                                                                           \
                                                ",
    "                                                                           \
                                                ",
    "                              mm??                                         \
                                                ",
    "                                                                           \
                                                ",
    "                                                                           \
          E                                     ",
    "    mm?                                                 mmmmm              \
                                                ",
    "                                         ?mm                         ??    \
            _                                    ",
    "                       m                                                   \
          _ | _                                   ",
    "                       mmm      EE                                         \
          | | |                         H       ",
    "mmmmmmmmmmmmmm   mmmmmmmmmmmmmmmmmmmmmmmmmmmm     mmmmmmmmmmmmm  mmmmmmmmmm\
mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm",
    "mmmmmmmmmmmmmm   mmmmmmmmmmmmmmmmmmmmmmmmmmmm     mmmmmmmmmmmmm  mmmmmmmmmm\
mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm",
  ],
  [
    "        q                                                                   \
                               q               ",
    "                                                                          q \
                                                ",
    "                                                                            \
                                                ",
    "                                                                            \
                      q                         ",
    "                                                        q                   \
                                                ",
    "                                                                            \
                                            q   ",
    "                                                                            \
    q                                           ",
    "                                                                            \
                                                ",
    "                                                                            \
                          q                    ",
    "                                                          q                 \
                                                ",
    "                                                                            \
                                                ",
    "         E                                                          ?lll    \
                                                ",
    "      ?ll?lll                                               ll              \
                        ??                      ",
    "                                       ll??           lbll                  \
                                                ",
    "                           b?                                               \
                                                ",
    "                _  _                                                        \
           _                                    ",
    "                |  |          E                             E               \
           | EE                           v     ",
    "lllllllllllllllllllllllllllll   lllllllllllllllllllllllllllllllllllllllllllll\
    lllllllllllllllllllllllllllllllllllllllllllll",
    "lllllllllllllllllllllllllllll   lllllllllllllllllllllllllllllllllllllllllllll\
    lllllllllllllllllllllllllllllllllllllllllllll",
  ],
  [
    "                                    q                                        \
              q                                ",
    "                                                                             \
                                      q        ",
    "                                                                             \
                                                ",
    "                                                                             \
                                                ",
    "                                                          q                  \
                            q                  ",
    "                                                                             \
                                                ",
    "                                                              q              \
                                                ",
    "                                                                             \
                                                ",
    "                                                                             \
                                                ",
    "                                                                             \
                                                ",
    "                                                        l??ll                \
                                                ",
    "                                                                             \
                                                ",
    "             lbll               l?l                                       llb\
            l?l                                 ",
    "                                         ?                                   \
                llll                            ",
    "                                                 _ _                         \
                                                ",
    "                                                 | |                         \
                                                ",
    "                                E                | |   E                     \
           l    l            E            v     ",
    "lllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll\
lllllllllllllllllllllllllllllllllllllllllllllllll",
    "lllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll\
lllllllllllllllllllllllllllllllllllllllllllllllll",
  ],
  [
    "                                                                            \
                                                ",
    "                                                                            \
                                                ",
    "                                                                            \
                                                ",
    "                                                                            \
                                                ",
    "                                                                            \
                                                ",
    "                          t                                  f              \
                                                ",
    "                                                                            \
                                                ",
    "        f                                     t                             \
                              t                ",
    "                                                                            \
                                                ",
    "                                                                           t\
                                              f ",
    "                                                                            \
                                                ",
    "                                      o??                                   \
                                                ",
    "                        o?o                                                 \
                                                ",
    "                 ooo                                              o???o     \
            _                                   ",
    "                                obo       ooo                               \
        _   |                                   ",
    "                                                _   _                       \
        |   |  _                                ",
    "                 i         E                    | E |        oo             \
        |   |  |      E       E          s      ",
    "ooooooooooooooooooooo  oooooooooooooooo    oooooooooooooo  ooooooooooooooooo\
oooooooooooooooooooooooooooooooooooooooooooooooo",
    "ooooooooooooooooooooooooooooooooooooooo    ooooooooooooooooooooooooooooooooo\
oooooooooooooooooooooooooooooooooooooooooooooooo",
  ],
  [
    "                                                                            \
                                                ",
    "                                                                            \
                                                ",
    "                                                                           t\
                                                ",
    "                                                                            \
                                                ",
    "                                        f                     f             \
                                                ",
    "                      t                                                     \
    t                                     t     ",
    "                                                                            \
              f                                 ",
    "                            f                                               \
                                                ",
    "                                                                            \
                                                ",
    "                                                                            \
                                                ",
    "                                                                            \
                                                ",
    "                    _                                         ooo           \
                                                ",
    "                    |                 EE                                    \
                                                ",
    "               oo?oooo?oo        ooooooooooo                                \
                oooo                            ",
    "                                                                   ?b?      \
          ?oo?o                                 ",
    "                                                                            \
      _                 oooo                    ",
    "        i                                  i   E     oo      oo    E i      \
      |          EE    i      i          s      ",
    "oooooo  oooooooooooo  ooooooooooooooooo    ooooooooooooo  oooooooooooooooooo\
oooooooooooooooooooooooooooooooooooooooooooooooo",
    "oooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo\
oooooooooooooooooooooooooooooooooooooooooooooooo",
  ],
  [

    "                                                                        \
                                    ",
    "                                                                        \
                                    ",
    "                                                                        \
                                    ",
    "                                                                        \
                                    ",
    "                                                                        \
                                    ",
    "                                                                        \
                                    ",
    "                                                                        \
                                    ",
    "                                                                        \
                                    ",
    "                                                                        \
                                    ",
    "                                                                        \
                                    ",
    "                                                                        \
                                    ",
    "                                  r?r                                   \
                                    ",
    "                                        ?                               \
                                    ",                                               
    "         r?rbr             r?r                                          \
                                    ",
    "                                                                        \
                                    ",
    "                                                             rrrrrr     \
                                    ",
    "                                      r?r                               \
                    ???             ",
    "                                                                        \
                                    ",
    "         _                                         _                    \
                                    ",
    "         |                                         |       E       E    \
                                  H ",
    "rrrrrrrrrrrrrrrr     rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\
rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr",
    "rrrrrrrrrrrrrrrr     rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\
rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr",
  ],
  [

    "                                                                        \
                                    ",
    "                                                                        \
                                    ",
    "                                                                        \
                                    ",
    "                                                                        \
                                    ",
    "                                                                        \
                                    ",
    "                                                                        \
                                    ",
    "                                                                        \
                                    ",
    "                                                                        \
                                    ",
    "                                                                        \
                                    ",
    "                                                                        \
                                    ",
    "                                                                        \
                                    ",
    "                                  r?r                                   \
                                    ",
    "                                        ?                               \
                                    ",                                               
    "                           r?r                                          \
                                    ",
    "                                                                        \
                rrrr                ",
    "                                                                    rr? \
                                    ",
    "                                                                        \
rrrbbr                              ",
    "                                                    rrrr                \
             _                      ",
    "         _              rrrrr                                           \
           _ |                      ",
    "         |                                EE                            \
 EE        | |     E           g    ",
    "rrrrrrrrrrrrrrrr     rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\
rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr",
    "rrrrrrrrrrrrrrrr     rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\
rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr",
  ]
];

const levelConf = {
  width: 16,
  height: 16,
  pos: vec2(0,0),

  "=": () => [
    sprite("ground"), 
    area(),
    solid(),
    origin("bot"),
    "ground"
  ],
  "o": () => [
    sprite("Ocean"), 
    area(),
    solid(),
    origin("bot"),
    "ocean"
  ],
  "v": () => [
    sprite("Volcano"), 
    area(),
    origin("bot"),
    "volcano"
  ],
  "q": () => [
    sprite("smokeCloud"), 
    area(),
    origin("bot"),
    "smokeCloud"
  ],
  "f": () => [
    sprite("clownFish"), 
    area(),
    origin("bot"),
    "clownFish"
  ],
  "t": () => [
    sprite("blueTang"), 
    area(),
    origin("bot"),
    "blueTang"
  ],
  "s": () => [
    sprite("sea"),
    area({ width: 1, height: 240 }),
    origin("bot"),
    "sea"
  ],
  "g": () => [
    sprite("gold"),
    area({ width: 1, height: 240 }),
    origin("bot"),
    "gold"
  ],
  "i": () => [
    sprite("pink"), 
    area(),
    origin("bot"),
    "pinkCoral"
  ],
  "d": () => [
    sprite("cloud"), 
    area(),
    origin("bot"),
    "cloud"
  ],
  "r": () => [
    sprite("rb"), 
    area(),
    solid(),
    origin("bot"),
    "rb"
  ],
  "l": () => [
    sprite("lava"), 
    area(),
    solid(),
    origin("bot"),
    "lava"
  ],
  "m": () => [
    sprite("moss"), 
    area(),
    solid(),
    origin("bot"),
    "moss"
  ],
  "-": () => [
    sprite("brick"),
    area(),
    solid(),
    origin("bot"),
    "brick"
  ],
  "H": () => [
    sprite("castle"),
    area({ width: 1, height: 240 }),
    origin("bot"),
    "castle"
  ],
  "?": () => [
    sprite("questionBox"),
    area(),
    solid(),
    origin("bot"),
    'questionBox',
    'coinBox'
  ],
  "b": () => [
    sprite("questionBox"),
    area(),
    solid(),
    origin("bot"),
    'questionBox',
    'mushyBox'
  ],
  "!": () => [
    sprite("emptyBox"),
    area(),
    solid(),
    bump(),
    origin("bot"),
    'emptyBox'
  ],
  "c": () => [
    sprite("coin"),
    area(),
    solid(),
    bump(64, 8),
    cleanup(),
    lifespan(0.4, { fade: 0.01 }),
     origin("bot"),
    "coin"
  ],
  "M": () => [
    sprite("bigMushy"),
    area(),
    solid(),
    patrol(10000),
    body(),
    cleanup(),
    origin("bot"),
    "bigMushy"
  ],
  "|": () => [
    sprite("pipeBottom"),
    area(),
    solid(),
    origin("bot"),
    "pipe"
  ],
  "_": () => [
    sprite("pipeTop"),
    area(),
    solid(),
    origin("bot"),
    "pipe"
  ],
  "E": () => [
    sprite("enemies", { anim: 'Walking' }),
    area({ width: 16, height: 16 }),
    solid(),
    body(),
    patrol(50),
    enemy(),
    origin("bot"),
    "badGuy"
  ],
  "p": () => [
    sprite("mario", { frame: 0 }),
    area({ width: 16, height: 16 }),
    body(),
    mario(),
    bump(150, 20, false),
    origin("bot"),
    "player"
  ]
  
};

scene("start", () => {
  addButton("Play", vec2(400,center().y),() => go("game"));
  addButton("Instructions", vec2(400,300),() => go("story"));
  add([
    sprite("cloud"),
    pos(20, 50),
    layer("bg")
  ]);
  add([
    sprite("cloud"),
    pos(400, 50),
    layer("bg")
  ]);
  add([
    sprite("cloud"),
    pos(750, 50),
    layer("bg")
  ]);
  add([
    sprite("sea"),
    pos(50, 200),
    layer("bg")
  ]);
  add([
    sprite("Volcano"),
    pos(600, 200),
    layer("bg")
  ]);
  add([
    text("World Adventures!", { size: 40 }),
    pos(vec2(400, 120)),
    origin("center"),
    color(255, 255, 255),
  ]);
});
go("start");

scene("story", () => {
  addButton("Back to Main", vec2(150,175),() => go("start"));
  add([
    text("Welcome to World Adventures! \nThere are ten levels. \nEvery two levels represents a new world: \nnormal, dungeon, lava, water, and rainbow. \nThe objective is to get to the end of the seond rainbow level \nand reach the pot of gold!", { size: 15 }),
    pos(vec2(20, 50)),
    origin("left"),
    color(255, 255, 255),
  ]);
  add([
    text("Use the arrows keys to mve left and right \nand spacebar to jump. \nIf you land on or touch a mushroom, \nthe game is over. \nIf you jump on top of a mushroom, \nyou kill the mushy and get points. \nTouch the giant structure, volcano, castle, or gold, \nto complete the level.", { size: 15 }),
    pos(vec2(20, 300)),
    origin("left"),
    color(255, 255, 255),
  ]);
});


let score = 0;
scene("game", (levelNumber = 0) => {
  
  layers([
    "bg",
    "game",
    "ui",
  ], "game");
  const level = addLevel(LEVELS[levelNumber], levelConf);
  
  add([
    text("Level " + (levelNumber + 1), { size: 24 }),
    pos(vec2(160, 120)),
    color(255, 255, 255),
    origin("center"),
    layer('ui'),
    lifespan(1, { fade: 0.5 })
  ]);
  
  const player = level.spawn("p", 1, 10)
  const SPEED = 120;
  onKeyDown("right", () => {
    if (player.isFrozen) return;
    player.flipX(false);
    player.move(SPEED, 0);
  });
  onKeyDown("left", () => {
    if (player.isFrozen) return;
    player.flipX(true);
    if (toScreen(player.pos).x > 20) {
      player.move(-SPEED, 0);
    }
  });
  onKeyPress("space", () => {
    if (player.isAlive && player.grounded()) {
      player.jump();
      canSquash = true;
    }
  });

  const scoreText = add([
    text(score, {size: 50})
  ]);
  
  player.onUpdate(() => {
    // center camera to player
    var currCam = camPos();
    if (currCam.x < player.pos.x) {
      camPos(player.pos.x, currCam.y);
    }
    if (player.isAlive && player.grounded()) {
      canSquash = false;
    }
    // Check if Mario has fallen off the screen
    if (player.pos.y > height() - 16){
      //killed();
      go("gameover", score);
      score = 0;
    }
  });

  let canSquash = false;
  player.onCollide("badGuy", (baddy) => {
    if (baddy.isAlive == false) return;
    if (player.isAlive == false) return;
    if (canSquash) {
      // Mario has jumped on the bad guy:
      baddy.squash();
      score += 10;
      scoreText.text = score;
    } else {
      // Mario has been hurt. 
      if (player.isBig) {
        player.smaller();
      } else {
        // Mario is dead :(
        //killed();
        go("gameover", score);
        score = 0;
      }
    }
  });
  

  player.on("headbutt", (obj) => {
    if (obj.is("questionBox")) {
      if (obj.is("coinBox")) {
        let coin = level.spawn("c", obj.gridPos.sub(0, 1));
        coin.bump();
        score += 100;
        scoreText.text = score;
      } else
      if (obj.is("mushyBox")) {
        level.spawn("M", obj.gridPos.sub(0, 1));
      }
      var pos = obj.gridPos;
      destroy(obj);
      var box = level.spawn("!", pos);
      box.bump();
    }
  });
  
  player.onCollide("bigMushy", (mushy) => {
    destroy(mushy);
    player.bigger();
    score += 5;
    scoreText.text = score;
  });
  
  player.onCollide("castle", (castle, side) => {
    player.freeze();
    score += 500;
    scoreText.text = score;
    add([
      text("Well Done!", { size: 24 }),
      pos(toWorld(vec2(160, 120))),
      color(255, 255, 255),
      origin("center"),
      layer('ui'),
    ]);
    wait(1, () => {
      let nextLevel = levelNumber + 1;
      if (nextLevel >= LEVELS.length) {
        go("gameover", score);
        score = 0;
      } else {
        go("game", nextLevel);
      } 
    })
  });
  
  player.onCollide("volcano", (volcano, side) => {
    player.freeze();
    score += 500;
    scoreText.text = score;
    add([
      text("Well Done!", { size: 24 }),
      pos(toWorld(vec2(160, 120))),
      color(255, 255, 255),
      origin("center"),
      layer('ui'),
    ]);
    wait(1, () => {
      let nextLevel = levelNumber + 1;
      if (nextLevel >= LEVELS.length) {
        go("gameover", score);
        score = 0;
      } else {
        go("game", nextLevel);
      } 
    })
  });

  player.onCollide("sea", (sea, side) => {
    player.freeze();
    score += 500;
    scoreText.text = score;
    add([
      text("Well Done!", { size: 24 }),
      pos(toWorld(vec2(160, 120))),
      color(255, 255, 255),
      origin("center"),
      layer('ui'),
    ]);
    wait(1, () => {
      let nextLevel = levelNumber + 1;
      if (nextLevel >= LEVELS.length) {
        go("gameover", score);
        score = 0;
      } else {
        go("game", nextLevel);
      } 
    })
  });
  
  player.onCollide("gold", (gold, side) => {
    player.freeze();
    score += 500;
    scoreText.text = score;
    add([
      text("Well Done!", { size: 24 }),
      pos(toWorld(vec2(160, 120))),
      color(255, 255, 255),
      origin("center"),
      layer('ui'),
    ]);
    wait(1, () => {
      let nextLevel = levelNumber + 1;
      if (nextLevel >= LEVELS.length) {
        go("gameover", score);
        score = 0;
      } else {
        go("game", nextLevel);
      } 
    })
  });
  
});

let highScore = 0;
scene("gameover", (score) => {
  if (score > highScore) {
    highScore = score;
  }

  add([
    text(
    "gameover!\n"
    + "score: " + score
    + "\nhigh score: " + highScore
    + "\npress space to play again",
    {size: 20}
    )
  ]);

  onKeyPress("space", () => {
    go("game");
  });

});

function patrol(distance = 100, speed = 50, dir = 1) {
  return {
    id: "patrol",
    require: ["pos", "area",],
    startingPos: vec2(0, 0),
    add() {
      this.startingPos = this.pos;
      this.on("collide", (obj, side) => {
        if (side === "left" || side === "right") {
          dir = -dir;
        }
      });
    },
    update() {
      if (Math.abs(this.pos.x - this.startingPos.x) >= distance) {
        dir = -dir;
      }
      this.move(speed * dir, 0);
    },
  };
}

function enemy() {
  return {
    id: "enemy",
    require: ["pos", "area", "sprite", "patrol"],
    isAlive: true,
    update() {
    },
    squash() {
      this.isAlive = false;
      this.unuse("patrol");
      this.stop();
      this.frame = 2;
      this.area.width = 16;
      this.area.height = 8;
      this.use(lifespan(0.5, { fade: 0.1 }));
    }
  }
}

function bump(offset = 8, speed = 2, stopAtOrigin = true) {
  return {
    id: "bump",
    require: ["pos"],
    bumpOffset: offset,
    speed: speed,
    bumped: false,
    origPos: 0,
    direction: -1,
    update() {
      if (this.bumped) {
        this.pos.y = this.pos.y + this.direction * this.speed;
        if (this.pos.y < this.origPos - this.bumpOffset) {
          this.direction = 1;
        }
        if (stopAtOrigin && this.pos.y >= this.origPos) {
          this.bumped = false;
          this.pos.y = this.origPos;
          this.direction = -1;
        }
      }
    },
    bump() {
      this.bumped = true;
      this.origPos = this.pos.y;
    }
  };
}

function mario() {
  return {
    id: "mario",
    require: ["body", "area", "sprite", "bump"],
    smallAnimation: "Running",
    bigAnimation: "RunningBig",
    smallStopFrame: 0,
    bigStopFrame: 8,
    smallJumpFrame: 5,
    bigJumpFrame: 13,
    isBig: false,
    isFrozen: false,
    isAlive: true,
    update() {
      if (this.isFrozen) {
        this.standing();
        return;
      }
      if (!this.grounded()) {
        this.jumping();
      }
      else {
        if (keyIsDown("left") || keyIsDown("right")) {
          this.running();
        } else {
          this.standing();
        }
      }
    },
    bigger() {
      this.isBig = true;
      this.area.width = 24;
      this.area.height = 32;
    },
    smaller() {
      this.isBig = false;
      this.area.width = 16;
      this.area.height = 16;
    },
    standing() {
      this.stop();
      this.frame = this.isBig ? this.bigStopFrame : this.smallStopFrame;
    },
    jumping() {
      this.stop();
      this.frame = this.isBig ? this.bigJumpFrame : this.smallJumpFrame;
    },
    running() {
      const animation = this.isBig ? this.bigAnimation : this.smallAnimation;
      if (this.curAnim() !== animation) {
        this.play(animation);
      }
    },
    freeze() {
      this.isFrozen = true;
    },
    die() {
      this.unuse("body");
      this.bump();
      this.isAlive = false;
      this.freeze();
      this.use(lifespan(1, { fade: 1 }));
    }
  }
}
function addButton(txt, p, f){

  const btn = add([
    text(txt),
    pos(p),
    area({cursor: "pointer",}),
    scale(1),
    origin("center"),
  ])

  btn.onClick(f);

  btn.onUpdate(() => {
    if (btn.isHovering()) {
      const t = time() * 10
      btn.color = RED
      btn.scale = vec2(.5)
    } else {
      btn.scale = vec2(.5)
      btn.color = WHITE
    }
  })
}

// function killed() {
//   // Mario is dead :(
//   if (player.isAlive == false) return; // Don't run it if mario is already dead
//   player.die();
//   add([
//     text("Game Over :(", { size: 24 }),
//     pos(toWorld(vec2(160, 120))),
//     color(255, 255, 255),
//     origin("center"),
//     layer('ui'),
//   ]);
//   wait(2, () => {
//     go("gameover", score);
//   })
// }



